package pe.com.integra.irene.shared.models.model;

public enum ResponseType {
    TEXT, AUDIO, NATIVE_AUDIO
}
